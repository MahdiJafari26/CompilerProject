package Lexical;

public class LexicalPart {
    public static String code;

    public static void main(String[] args) {
        System.out.println("hello world!");

    }

}
